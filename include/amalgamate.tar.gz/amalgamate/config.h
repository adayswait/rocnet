// Configures the Juce library.

#ifndef   JUCE_FORCE_DEBUG
//#define JUCE_FORCE_DEBUG
#endif

#ifndef   JUCE_LOG_ASSERTIONS
//#define JUCE_LOG_ASSERTIONS
#endif

#ifndef   JUCE_CHECK_MEMORY_LEAKS
//#define JUCE_CHECK_MEMORY_LEAKS
#endif

#ifndef   JUCE_DONT_AUTOLINK_TO_WIN32_LIBRARIES
//#define JUCE_DONT_AUTOLINK_TO_WIN32_LIBRARIES
#endif
